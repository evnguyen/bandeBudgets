# Budget App - Zero-Based Budgeting

A comprehensive budgeting application inspired by EveryDollar, built with Next.js, Firebase, and Zustand.

## Features

### Dual Authentication System
- **Site Password Protection**: Long-lived token (1 year) to restrict site access
- **Firebase Authentication**: User accounts with email/password login and signup

### Budget Management
- **Zero-Based Budgeting**: Track income and expenses to achieve zero remaining balance
- **Categories**: Organize budget items into custom categories (Income/Expense)
- **Budget Items**: Create line items with planned amounts within each category
- **Transactions**: Record actual transactions against budget items
- **Month Navigation**: Switch between months to view and manage different budget periods
- **Real-time Calculations**: Automatic totals and remaining balance calculations

### Theme Customization
- **Customizable Colors**: Choose from 6 preset color schemes for primary and secondary colors
- **Persistent Settings**: Theme preferences saved to Firebase and applied on login
- **Available Colors**: Blue, Green, Purple, Orange, Red, Teal

### Responsive Design
- Mobile-first approach
- Adapts seamlessly to tablets and desktop screens
- Touch-friendly interfaces

## Tech Stack

- **Framework**: Next.js 16 with App Router
- **Authentication**: Firebase Auth
- **Database**: Cloud Firestore
- **State Management**: Zustand
- **UI Components**: shadcn/ui + Radix UI
- **Styling**: Tailwind CSS
- **Type Safety**: TypeScript

## Getting Started

### 1. Install Dependencies

\`\`\`bash
pnpm install
\`\`\`

### 2. Set Up Firebase

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project
3. Enable Authentication (Email/Password)
4. Create a Firestore database
5. Copy your Firebase configuration

### 3. Environment Variables

Copy `.env.example` to `.env.local` and fill in your Firebase credentials:

\`\`\`bash
cp .env.example .env.local
\`\`\`

Update the values in `.env.local` with your actual Firebase configuration.

### 4. Run Development Server

\`\`\`bash
pnpm dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Usage

### First Time Setup

1. **Site Access**: Enter the site password (default: `demo123`)
2. **Create Account**: Sign up with your email and password
3. **Start Budgeting**: Create categories and budget items

### Creating a Budget

1. **Add Categories**: Click "Add Category" and choose Income or Expense type
2. **Add Budget Items**: Within each category, add items with planned amounts
3. **Record Transactions**: Click "Add Transaction" on any budget item to record actual spending/income
4. **Monitor Progress**: View real-time progress bars and remaining balances

### Theme Customization

1. Click the Settings icon in the top right
2. Choose your preferred primary and secondary colors
3. Colors are saved automatically and persist across sessions

## Architecture

### State Management (Zustand)

- **authStore**: Manages authentication state and site access tokens
- **budgetStore**: Handles all budget data and Firebase operations
- **settingsStore**: Manages user preferences and theme settings

### Data Structure

```typescript
Budget
├── Categories (Income/Expense)
│   └── Budget Items
│       ├── Planned Amount
│       ├── Spent Amount
│       └── Transactions
│           ├── Amount
│           ├── Description
│           └── Date
```

### Best Practices Implemented

- **DRY (Don't Repeat Yourself)**: Reusable components and shared logic
- **KISS (Keep It Simple)**: Clear component hierarchy and straightforward state management
- **Type Safety**: Full TypeScript coverage with defined interfaces
- **Separation of Concerns**: Clear separation between UI, state, and Firebase logic
- **Code Organization**: Logical folder structure for easy navigation and modification

## Firebase Security Rules

Remember to set up proper Firestore security rules:

\`\`\`javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Budgets - users can only access their own budgets
    match /budgets/{budgetId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == resource.data.userId;
      allow create: if request.auth != null;
    }
    
    // Settings - users can only access their own settings
    match /settings/{userId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == userId;
    }
  }
}
\`\`\`

## Customization

### Changing Site Password

Update `NEXT_PUBLIC_SITE_PASSWORD` in your `.env.local` file.

### Adding More Theme Colors

1. Edit `lib/theme-colors.ts` to add new color options
2. Colors use HSL format: `hue saturation% lightness%`

### Modifying Budget Logic

- Budget calculations: `lib/stores/budget-store.ts`
- Transaction types: `lib/types.ts`
- UI components: `components/budget/`

## License

This project is open source and available for personal and commercial use.
